# src/processing/transformations.py
from pyspark.sql import DataFrame
from pyspark.sql import functions as F


class Transformation:
    """
    Nossa lógica
    """

    ## Adicionando no relatório o valor total do pedido

    def avaliacao_fraude(self, df_pagamentos: DataFrame) -> DataFrame:
        return (
            df_pagamentos.withColumn("fraude", F.col("avaliacao_fraude.fraude"))
            .withColumn("score", F.col("avaliacao_fraude.score"))
            .drop("avaliacao_fraude")
        )

    def add_valor_total_pedidos(self, df_pedidos: DataFrame) -> DataFrame:
        return df_pedidos.withColumn(
            "VALOR_TOTAL", F.col("VALOR_UNITARIO") * F.col("QUANTIDADE")
        )

    def filtra_pagamentos(self, df_pagamentos: DataFrame) -> DataFrame:
        return df_pagamentos.filter(
            (F.col("status") == False) & (F.col("fraude") == False)
        )

    def filtra_pedidos(self, df_pedidos_filtrado: DataFrame) -> DataFrame:
        return df_pedidos_filtrado.filter((F.year(F.col("DATA_CRIACAO")) == 2025))

    def join_pagamentos_pedidos(
        self, df_pagamento_filtrado: DataFrame, df_pedidos_filtrado: DataFrame
    ) -> DataFrame:
        return df_pagamento_filtrado.join(
            df_pedidos_filtrado, on="ID_PEDIDO", how="inner"
        ).select("id_pedido", "UF", "forma_pagamento", "VALOR_UNITARIO", "DATA_CRIACAO")

    def ordenar(self, df_relatorio: DataFrame) -> DataFrame:
        return df_relatorio.orderBy(
            F.col("UF").asc(),
            F.col("forma_pagamento").desc(),
            F.col("DATA_CRIACAO").desc(),
        )
